var routerContractAddress = '0x1411cb266fced1587b0aa29e9d5a9ef3db64a9c5';
var manufacturerDirectoryContractAddress = '0x855d1c79ad3fb086d516554dc7187e3fdfc1c79a';
var carDealerContractAddress = '0xbbe595df857805ab3734f15be990f9a30cbb89f3';
var carFactoryContractAddress = '0x7153ccd1a20bbb2f6dc89c1024de368326ec6b4f';
var tokenContractAddress = '0x8065f4c7b8c2bf53561af92d9da2ea022a0b28ca';
